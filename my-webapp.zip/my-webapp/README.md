# my-webapp
Ejemplo en Node JS para dockerizar en CloudFoundry de IBM Cloud

## Clonamos el proyecto my-webapp
```
git clone https://github.com/afforeroc/my-webapp.git
```

## Instalamos las librerías requeridas
```
npm install
npm install express
npm install pug
```

## Probamos my-webapp en local
```
node app.js
```

## Configuraciones sobre IBM Cloud
```
ibmcloud plugin install container-registry –r Bluemix
ibmcloud login
ibmcloud target --cf
ibmcloud cr namespace-add docker-space
```

## Construcción y envio de cambios al Container Registry de IBM Cloud
```
docker build –t registry.ng.bluemix.net/docker-space/my-webapp:latest .
docker push registry.ng.bluemix.net/docker-space/my-webapp:latest
```

## Accedemos al panel de gestión de API keys
```
https://console.bluemix.net/iam/#/apikeys
```

## Guardar API key generado
```
$env:CF_DOCKER_PASSWORD="<API Key generico>"
```

## Desplegar my-webapp en Cloud Foundry de IBM Cloud
```
ibmcloud cf push my-webappx -o registry.ng.bluemix.net/docker-space/my-webapp:latest --docker-username iamapikey
```
